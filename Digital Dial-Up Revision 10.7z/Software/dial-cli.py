import os
import time
import tempfile
import shutil
import gc
import numpy as np  # Import numpy for calculating mean
from pydub import AudioSegment
from pydub.generators import Sine

# Function to display progress and estimate time remaining
def display_progress(current_bit, total_bits, start_time):
    elapsed_time = time.time() - start_time
    progress = current_bit / total_bits
    estimated_total_time = elapsed_time / progress if progress > 0 else 0
    eta = estimated_total_time - elapsed_time

    # Formatting ETA into days, hours, minutes, and seconds
    eta_days = int(eta // 86400)
    eta_hours = int((eta % 86400) // 3600)
    eta_minutes = int((eta % 3600) // 60)
    eta_seconds = int(eta % 60)

    # Display the progress
    print(f"\rProgress: {progress * 100:.2f}% - "
          f"Elapsed Time: {elapsed_time:.2f}s - "
          f"ETA: {eta_days}d {eta_hours}h {eta_minutes}m {eta_seconds}s", end='')

# Function to concatenate temporary audio files into one final file
def concatenate_temp_files(temp_audio_files, output_file, output_format):
    print("\nCombining all temporary files into the final audio...")

    # Create an empty output file
    with open(output_file, 'wb') as outfile:
        for temp_file in temp_audio_files:
            print(f"Processing {temp_file}...")

            # Open each temporary file and append its content to the output file
            try:
                with open(temp_file, 'rb') as infile:
                    while True:
                        # Read in chunks to avoid loading everything into memory
                        chunk = infile.read(1024 * 1024)  # Read 1 MB at a time
                        if not chunk:
                            break
                        outfile.write(chunk)
                print(f"Finished reading {temp_file}")

            except Exception as e:
                print(f"Error while reading {temp_file}: {e}")
                continue

            # Ensure file is closed and flushed properly before attempting to delete it
            try:
                os.remove(temp_file)
                print(f"Temporary file {temp_file} removed.")
            except PermissionError as e:
                print(f"Failed to remove {temp_file}: {e}. Retrying after a short delay...")
                time.sleep(1)  # Short delay before retrying
                try:
                    os.remove(temp_file)
                    print(f"Temporary file {temp_file} removed after retry.")
                except Exception as e:
                    print(f"Failed to remove {temp_file} after retry: {e}")
    print(f"All temporary files combined into {output_file} in {output_format} format.")

# Function to encode the input file to audio format
def encode_file_to_audio(input_file, output_file, output_format, temp_dir, sample_rate=44100, duration_per_bit=0.05, save_interval=15*60):
    # Read file content
    with open(input_file, 'rb') as f:
        file_data = f.read()

    # Convert file bytes to bits
    file_bits = ''.join(format(byte, '08b') for byte in file_data)
    total_bits = len(file_bits)

    # Pre-generate 500Hz and 750Hz tones
    tone_0 = Sine(500).to_audio_segment(duration=duration_per_bit * 1000, volume=-3)
    tone_1 = Sine(750).to_audio_segment(duration=duration_per_bit * 1000, volume=-3)

    # Track the start time and time for saving progress
    start_time = time.time()
    last_save_time = start_time

    # Process the bits in chunks for speed and periodic saving (batch of 1024 bits at a time)
    chunk_size = 1024
    current_audio = AudioSegment.silent(duration=0)
    temp_audio_files = []

    for i in range(0, total_bits, chunk_size):
        chunk = file_bits[i:i + chunk_size]
        chunk_audio = AudioSegment.silent(duration=0)
        
        # Generate audio for the chunk
        for bit in chunk:
            chunk_audio += tone_0 if bit == '0' else tone_1

        # Append chunk to the current audio
        current_audio += chunk_audio

        # Update progress and time info
        display_progress(i + len(chunk), total_bits, start_time)

        # Periodically save progress every 'save_interval' seconds
        if time.time() - last_save_time >= save_interval:
            # Save the current audio to a temporary file in the specified temp_dir
            temp_file = tempfile.NamedTemporaryFile(delete=False, suffix=".wav", dir=temp_dir)
            current_audio.export(temp_file.name, format="wav")
            temp_audio_files.append(temp_file.name)

            # Clear memory
            current_audio = AudioSegment.silent(duration=0)
            last_save_time = time.time()

            # Force garbage collection to free up RAM
            gc.collect()

    # Save remaining audio to a temporary file
    if len(current_audio) > 0:
        temp_file = tempfile.NamedTemporaryFile(delete=False, suffix=".wav", dir=temp_dir)
        current_audio.export(temp_file.name, format="wav")
        temp_audio_files.append(temp_file.name)
        # Explicitly close to ensure it's fully written
        temp_file.close()

    # Incrementally concatenate all temporary audio files to the final output
    concatenate_temp_files(temp_audio_files, output_file, output_format)

# Function to decode audio back to the original binary file
def decode_audio_to_file(input_file, output_file, temp_dir, sample_rate=44100, duration_per_bit=0.05, save_interval=15*60):
    # Load the audio file
    audio = AudioSegment.from_file(input_file)

    # Calculate the number of samples per bit
    samples_per_bit = int(sample_rate * duration_per_bit)

    # Extract raw audio data
    raw_data = np.array(audio.get_array_of_samples())

    total_chunks = len(raw_data) // samples_per_bit

    start_time = time.time()
    last_save_time = start_time

    # Iterate over chunks of the audio and decode
    bits = ""
    decoded_data = bytearray()

    for i in range(0, len(raw_data), samples_per_bit):
        chunk = raw_data[i:i + samples_per_bit]
        # Compute the frequency by analyzing the chunk
        fft_result = np.fft.fft(chunk)
        freqs = np.fft.fftfreq(len(fft_result))
        dominant_freq = abs(freqs[np.argmax(np.abs(fft_result))]) * sample_rate
        if 450 <= dominant_freq <= 550:  # 500 Hz tone
            bits += '0'
        elif 700 <= dominant_freq <= 800:  # 750 Hz tone
            bits += '1'

        # If we have a full byte, convert it and append to decoded data
        if len(bits) >= 8:
            decoded_data.append(int(bits[:8], 2))
            bits = bits[8:]

        # Update progress and time info
        display_progress(i // samples_per_bit + 1, total_chunks, start_time)

        # Periodically save progress every 'save_interval' seconds
        if time.time() - last_save_time >= save_interval:
            # Save the current decoded data to a temporary file in the specified temp_dir
            temp_file = tempfile.NamedTemporaryFile(delete=False, suffix=".bin", dir=temp_dir)
            with open(temp_file.name, 'ab') as f:
                f.write(decoded_data)

            # Clear memory
            decoded_data = bytearray()
            last_save_time = time.time()

            # Force garbage collection to free up RAM
            gc.collect()

    # Save any remaining decoded data to the output file
    if len(decoded_data) > 0:
        with open(output_file, 'ab') as f:
            f.write(decoded_data)

    print(f"\nDecoding complete. File saved at {output_file}.")

# Main interactive function
def interact_with_user():
    print("Digital File to Audio Converter\n")
    print("Please choose an option:")
    print("1. Encode a file to audio")
    print("2. Decode an audio file back to the original file")

    choice = input("> ")

    if choice == "1":
        input_file = input("Please enter the path for the input file (e.g., file.bin): ").strip()
        output_file = input("Please enter the path for the output audio file (e.g., file.wav): ").strip()
        output_format = input("Please enter the desired audio format (wav/mp3/flac): ").strip().lower()
        temp_dir = input("Please enter the path for the temporary directory (or press Enter for default): ").strip()

        # Validate temp_dir or use default
        if not temp_dir:
            temp_dir = tempfile.gettempdir()
        elif not os.path.exists(temp_dir):
            print(f"Directory {temp_dir} does not exist.")
            return
        elif not os.access(temp_dir, os.W_OK):
            print(f"Directory {temp_dir} is not writable.")
            return

        encode_file_to_audio(input_file, output_file, output_format, temp_dir)
    
    elif choice == "2":
        input_file = input("Please enter the path for the input audio file (e.g., file.wav): ").strip()
        output_file = input("Please enter the path for the output file (e.g., file.bin): ").strip()
        temp_dir = input("Please enter the path for the temporary directory (or press Enter for default): ").strip()

        # Validate temp_dir or use default
        if not temp_dir:
            temp_dir = tempfile.gettempdir()
        elif not os.path.exists(temp_dir):
            print(f"Directory {temp_dir} does not exist.")
            return
        elif not os.access(temp_dir, os.W_OK):
            print(f"Directory {temp_dir} is not writable.")
            return

        decode_audio_to_file(input_file, output_file, temp_dir)
    
    else:
        print("Invalid choice, exiting...")

# Entry point
if __name__ == "__main__":
    interact_with_user()
